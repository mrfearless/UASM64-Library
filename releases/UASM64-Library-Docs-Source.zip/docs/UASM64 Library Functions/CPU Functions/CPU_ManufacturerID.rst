.. _CPU_ManufacturerID:

==================
CPU_ManufacturerID
==================

Return a constant value that is a reference to the CPU manufacturer. 

::

   CPU_ManufacturerID PROTO 

**Parameters**


**Returns**

EAX contains a a constant value that is a reference to the CPU manufacturer or 0 (CPU_MANUFACTURER_NONE) if not supported, unknown or an error occurred.

One of the following values if successful:

* ``CPU_MANUFACTURER_INTEL``
* ``CPU_MANUFACTURER_IOTEL``
* ``CPU_MANUFACTURER_AMD``
* ``CPU_MANUFACTURER_CYRIX``
* ``CPU_MANUFACTURER_CENTAUR``
* ``CPU_MANUFACTURER_IDTWINCHIP``
* ``CPU_MANUFACTURER_TRANSMETACPU``
* ``CPU_MANUFACTURER_TRANSMETA``
* ``CPU_MANUFACTURER_NATSEMI``
* ``CPU_MANUFACTURER_NEXGEN``
* ``CPU_MANUFACTURER_RISE``
* ``CPU_MANUFACTURER_SIS``
* ``CPU_MANUFACTURER_UMC``
* ``CPU_MANUFACTURER_VORTEX``
* ``CPU_MANUFACTURER_ZHAOXIN``
* ``CPU_MANUFACTURER_HYGON``
* ``CPU_MANUFACTURER_RDCSEMI``
* ``CPU_MANUFACTURER_ELBRUS``
* ``CPU_MANUFACTURER_VIA``
* ``CPU_MANUFACTURER_AMDSAMPLE``
* ``CPU_MANUFACTURER_AO486``
* ``CPU_MANUFACTURER_MISTER``
* ``CPU_MANUFACTURER_V586s``
* ``CPU_MANUFACTURER_MSX86TOARM``
* ``CPU_MANUFACTURER_APPLEROSETTA2``
* ``CPU_MANUFACTURER_VIRTUALAPPLE``

