.. _CPU_Manufacturer:

================
CPU_Manufacturer
================

Return a string with the CPU manufacturer. 

::

   CPU_Manufacturer PROTO 


**Parameters**


**Returns**

RAX contains a pointer to a string containing the CPU manufacturer or 0 if not supported.


